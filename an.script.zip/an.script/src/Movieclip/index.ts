


export class Movieclip {

  constructor() {

  }

}