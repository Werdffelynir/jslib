


export class Mouse {

  constructor() {

  }

}