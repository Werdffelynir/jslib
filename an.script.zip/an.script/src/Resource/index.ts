




export class Resource {

  constructor() {

  }

}