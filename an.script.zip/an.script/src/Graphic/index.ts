


export class Graphic {

  constructor() {

  }

}