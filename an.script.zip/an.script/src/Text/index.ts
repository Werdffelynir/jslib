


export class Text {

  constructor() {

  }

}


