


export class TextField {

  constructor() {

  }

}