


export class Sprite {

  constructor() {

  }

}