Animate.Extension(function (insance) {

    if (!(insance instanceof Animate))
        return;
    var

        /**
         * @type Animate.prototype
         */
        that = insance,

        /**
         * @type CanvasRenderingContext2D
         */
        context = insance.getContext(),

        Text = {
            font: '12px Arial, sans',
            textAlign: 'start',
            textBaseline: 'top',
            direction: 'inherit',
            lineWidth: 1,
            color: '#000000'
        };


    Text.write = function (x, y, label, color, fill) {

        if (Text.font)          context.font = Text.font;
        if (Text.textAlign)     context.textAlign = Text.textAlign;
        if (Text.textBaseline)  context.textBaseline = Text.textBaseline;
        if (Text.direction)     context.direction = Text.direction;
        if (Text.lineWidth)     context.lineWidth = Text.lineWidth;
        if (Text.color)         color = Text.color;

        context.beginPath();

        if (fill === true || fill === undefined) {
            context.fillStyle = color || '#dddddd';
            context.fillText(label, x, y);

            if (typeof fill === 'string') {
                context.strokeStyle = fill || '#000000';
                context.strokeText(label, x, y);
            }
        }
        else {
            context.strokeStyle = color || '#000000';
            context.strokeText(label, x, y);
        }

        context.closePath();
    };

    insance.Text = Text;
})