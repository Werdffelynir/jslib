/** Expansion Base **/
(function (prototype) {

    prototype.onFrameBefore = null;
    prototype.onFrameAfter = null;

    prototype.onClick = null;
    prototype.onMousemove = null;
    prototype.onKeyup = null;
    prototype.onKeydown = null;

})(Animate.prototype)