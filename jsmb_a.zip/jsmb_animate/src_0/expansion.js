/** Expansion Base **/
(function (prototype) {

    /*assign static as instance methods*/

    //prototype.canvas = Animate.canvas;

})(Animate.prototype)