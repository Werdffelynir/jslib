const WebSocketServer = require('rpc-websockets').Server;


const server = new WebSocketServer({
  port: 8088,
  host: 'localhost'
});

server.register('getblock', function(params) {
  return { data: params}
});



