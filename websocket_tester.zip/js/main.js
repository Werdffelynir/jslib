document.addEventListener('DOMContentLoaded', () => {

  /* ------------------------------------------------------------- */
  const serverHost = "ws://127.0.0.1:8080/v1";
  const socket = new WebSocket(serverHost);

  socket.onopen = function() {
    logger("Connected to " + serverHost);
  };

  socket.onclose = function(event) {
    if (event.wasClean) {
      logger("Connect closed", 'colorBlue');
    } else {
      logger("Connect filed", 'colorRed');
    }
    logger("Code to " + event.code + ' reason: ' + event.reason);
  };

  socket.onmessage = function(event) {
    const {data} = event;
    logger('Result:' + data, 'colorBlue');
  };

  socket.onerror = function(error) {
    logger("Connection Error: Look into console log", 'colorRed');
    console.log('Connection Error Log:', error)
  };

  /* ------------------------------------------------------------- */

  const textareaJson = document.querySelector('#textareaJson');
  const buttonSend = document.querySelector('#buttonSend');
  const jsonsHTMLElement = document.querySelector('select#jsons');
  const logHTMLElement = document.querySelector('#log');

  /**
   * { jsonrpc: "2.0", method: 'getblock', params: {}, id: 123456789 }
   * { limit: 10, offset: 0, sort: "height:desc" }
   * @type {*}
   */
  const jsonList = {

    'getstatus': `{
  "jsonrpc": "2.0",
  "method": "GET_STATUS",
  "params": null,
  "id": 123456789
}`,

    'getblock': `{
  "jsonrpc": "2.0",
  "method": "GET_BLOCK",
  "params": { "id": "10793660026199324704" },
  "id": 123456789
}`,

    'getblocks': `{
  "jsonrpc": "2.0",
  "method": "GET_BLOCKS",
  "params": { "limit": 10, "offset": 0, "sort": "height:desc" },
  "id": 123456789
}`,

    'gettransaction': `{
  "jsonrpc": "2.0",
  "method": "gettransaction",
  "params": { "id": "12166312224816013186" },
  "id": 123456789
}`,

    'gettransactions': `{
  "jsonrpc": "2.0",
  "method": "gettransactions",
  "params": { "limit": 10, "offset": 0 },
  "id": 123456789
}`,

    'addtransaction': `{
  "jsonrpc": "2.0",
  "method": "addtransaction",
  "params": {
	  "id": "222675625422353767",
	  "amount": "150000000",
	  "fee": "1000000",
	  "type": 0,
	  "timestamp": 28227090,
	  "senderId": "12668885769632475474L",
	  "senderPublicKey": "2ca9a7143fc721fdc540fef893b27e8d648d2288efa61e56264edf01a2c23079",
	  "senderSecondPublicKey": "2ca9a7143fc721fdc540fef893b27e8d648d2288efa61e56264edf01a2c23079",
	  "recipientId": "12668885769632475474L",
	  "signature": "2821d93a742c4edf5fd960efad41a4def7bf0fd0f7c09869aed524f6f52bf9c97a617095e2c712bd28b4279078a29509b339ac55187854006591aa759784c205",
	  "signSignature": "2821d93a742c4edf5fd960efad41a4def7bf0fd0f7c09869aed524f6f52bf9c97a617095e2c712bd28b4279078a29509b339ac55187854006591aa759784c205",
	  "signatures": [
		  "72c9b2aa734ec1b97549718ddf0d4737fd38a7f0fd105ea28486f2d989e9b3e399238d81a93aa45c27309d91ce604a5db9d25c9c90a138821f2011bc6636c60a"
	  ],
	  "asset": {}
  },
  "id": 123456789
}`,

    'addtransaction PUT': `{
  "jsonrpc": "2.0",
  "method": "addtransaction",
  "params": {  
    "secret" : "wagon stock borrow episode laundry kitten salute link globe zero feed marble",  
    "amount" : 100000000, 
    "recipientId" : "DDK5216737955302030643" 
  },
  "id": 123456789
}`,

    'estimatefee': `{
  "jsonrpc": "2.0",
  "method": "estimatefee",
  "params": null,
  "id": 123456789
}`,

    'getbroadhash': `{
  "jsonrpc": "2.0",
  "method": "getbroadhash",
  "params": null,
  "id": 123456789
}`,

  };

  for (let key in jsonList) {
    const opt = document.createElement('option');
    opt.value = opt.textContent = key;
    jsonsHTMLElement.appendChild(opt);
  }

  textareaJson.value = jsonList[Object.keys(jsonList)[0]];
  jsonsHTMLElement.onchange = function (eve) {
    textareaJson.value = jsonList[eve.target.value];
  };

  function logger(text, className) {
    logger.counter ++;
    const li = document.createElement('li');
    li.className = className || '';
    li.innerHTML = '<b>' + logger.counter + ':</b> ' + text;
    logHTMLElement.insertBefore(li, logHTMLElement.firstChild);
  }
  logger.counter = 0;

  buttonSend.onclick = function (eve) {
    logger('Send:' + textareaJson.value, 'colorGrin');
    socket.send(String(textareaJson.value));
  };

  function save(name, value) {
    window.localStorage.setItem(name, value);
  }
  function getSave(name) {
    window.localStorage.key(name);
  }

});
